## Using Play-With-Docker

- Open a new browser tab to [www.play-with-docker.com](http://www.play-with-docker.com/)

- Confirm that you're not a robot

- Click on "ADD NEW INSTANCE": congratulations, you have your first Docker node!

- When you will need more nodes, just click on "ADD NEW INSTANCE" again

- Note the countdown in the corner; when it expires, your instances are destroyed

- If you give your URL to somebody else, they can access your nodes too
  <br/>
  (You can use that for pair programming, or to get help from a mentor)

- Loving it? Not loving it? Tell it to the wonderful authors,
  [@marcosnils](https://twitter.com/marcosnils) &
  [@xetorthio](https://twitter.com/xetorthio)!
