## Intros

- Hello! I am:

   - Pierre Zemb ([@PierreZ](https://twitter.com/PierreZ), OVHcloud)

- The workshop will run from 5:45pm to 7:45pm

- Feel free to interrupt for questions at any time

- *Especially when you see full screen container pictures!*